import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { Constants } from 'expo';
import TimerCountdown from 'react-native-timer-countdown';

export default class Timer extends React.Component {
  // Use the state to store time left
  // Anything that is supposed update on the screen due to
  // user interaction or passage of time (aka DYNAMIC)
  state = {
    timeLeft: 25 * 60 * 1000,
  };

  // Constructor is the first function that activates
  // inside a component when the component is created
  constructor() {
    super();
    // setInterval is a function that activates the callback
    // function every X milliseconds
    // setInterval( callback-function, X)
    setInterval(() => {
      // We cannot change in the state directly, we must setState
      let currentTimeLeft = this.state.timeLeft;
      this.setState({
        timeLeft: currentTimeLeft - 1000,
      });
    }, 1000);
    // NET EFFECT: Every 1000ms (i.e, 1 sec) that elapsed,
    // reduce timeLeft by 1000ms (i.e, 1 sec)
  }

  render() {
    return (
      <View style={styles.container}>
        <Text>{Math.floor(this.state.timeLeft / (60 * 1000))}</Text>
        <Text>:</Text>
        <Text>{(this.state.timeLeft % (60 * 1000)) / 1000}</Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    flexDirection: 'row',
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
});
