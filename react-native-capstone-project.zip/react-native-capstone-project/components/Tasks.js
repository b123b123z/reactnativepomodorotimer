import * as React from 'react';
import { Text, View, StyleSheet, FlatList, TextInput, TouchableOpacity, Button, AsyncStorage } from 'react-native';
import { Constants } from 'expo';
import CheckBox from 'react-native-check-box'

  
export default class App extends React.Component {

onGotoProfile = (todo) => {
    this.props.navigation.navigate('Countdown',{someMessage:todo});
  }

   onSave = async ()  => {
    try {
      let dataString = JSON.stringify(this.state.todo);
      await AsyncStorage.setItem('todo', dataString);
      alert("Data Saved")
    } catch (e) {
      alert("Unable to save data")
    }
  }

  onLoad = async() => {
    try {
      let dataString = await AsyncStorage.getItem("todo");
      const todos = JSON.parse(dataString);
      this.setState({todo: todos});
    } catch (e) {
      alert("Error loading");
    }
  }

 state = {
   // STEP 2: Add a state property to represent the new todo we add in
   nextTodo:'',
   // STEP 1: Define a list of todo inside the STATE
   // todo is an array of objects
    todo : [
      {
        id: 1,    // is uniquely identify the item
        title:'Walk the dog', // human readable name
        done: true  // indicate whether the todo item is done or not
      },
      {
        id: 2,
        title:'Pay the Bills',
        done: false
      },
      {
        id: 3,
        title: 'Pay Income Tax at IRAS',
        done: false
      }
    ]
 }

 addTodo = () => {
   let newTodo = this.state.nextTodo;
   // STEP 1: clone the existing todo array
   const clonedTodoList = [...this.state.todo, {
      id: Math.random() * 10000,
      title: newTodo,
      done: false
   }]; // STEP 2:modify the cloned array

   // STEP 3: Set the clonedTodoList into the state, overwritting
   // the original todo
   this.setState({
     todo: clonedTodoList
   })
 }

 toggleTodo = (todo) => {
    // Clone the array
    const clonedTodoList = [...this.state.todo];
    // Use a for loop to go through each of the item in the array
    for (let i=0; i < clonedTodoList.length; i++)
    {
      // find the item that is toggled by id
      if (clonedTodoList[i].id == todo.id) {
        // clone the todo item
        clonedTodoList[i] = {
          id: todo.id,
          title: todo.title,
          done: !todo.done // ..but inverse its done status
        }
      }
    }
      this.setState({
      todo: clonedTodoList
    })
 }

  // arrow function
   displayTodo = (flatListItem) => {
     return (
       <View style={{flexDirection: 'row', justifyContent: 'space-between' }}>
          <CheckBox isChecked={flatListItem.item.done} 
            onClick={
              () => {
                this.toggleTodo(flatListItem.item)
              }
            } />
          <TouchableOpacity onPress={()=>{
            this.onGotoProfile(flatListItem.item.title)
          }}>
              <Text style = {{fontFamily: 'Futura-MediumItalic'}}>{flatListItem.item.title}</Text>
          </TouchableOpacity>
           <Button title="Delete" onPress={()=>{
          this.onDeleteTodo(flatListItem)
        }}></Button>
       </View>
     );
    }

    onDeleteTodo = (flatListItem) =>{
    let indexToDelete = -1;
     for (let i=0; i < this.state.todo.length; i++)
    {
      if (flatListItem.item.id == this.state.todo[i].id) {
       indexToDelete = i;
       break;
      }
    }

    if (indexToDelete != -1){
      // MAKE A COPY OF THE ORIGINAL ARRAY
       let todoNew = [...this.state.todo];
       // DELETE THE ONE WHO DON'T WANT
       todoNew.splice(indexToDelete, 1);
       // REPLACE THE COPY INTO THE STATE
       this.setState({todo: todoNew});
    }
   
    

  }

  // function
  render() {  
    return (
      <View style = {styles.container}>
      <Text style = {styles.container}>My Tasks</Text>
        <FlatList
          data={this.state.todo}
          renderItem={this.displayTodo}
          style={{height:300}}
        />
        <TextInput value={this.state.nextTodo} 
           onChangeText={(incomingText)=>{
             console.log(incomingText);
            this.setState({
              nextTodo:incomingText
            })
         }}
          style={{
          borderWidth:1,
          borderColor:'black',
          borderStyle:'solid',
          height:30,
          padding:5 
        }}/>
        <Button title="Add Task" onPress={this.addTodo}/>
        <Button title="Save" onPress={this.onSave}></Button>
        <Button title="Load" onPress={this.onLoad}></Button>
      </View>

    );
  }
}

const styles = StyleSheet.create({
  container: {
    paddingTop: Constants.statusBarHeight,
    padding: 8,
    fontFamily: 'Futura-MediumItalic',
    color: 'black',
    fontWeight: 'bold',
  }
});
