import * as React from 'react';
import { Constants } from 'expo';
import {
  Text,
  View,
  StyleSheet,
  Image,
  Button,
  ImageBackground,
} from 'react-native';

export default class Countdown extends React.Component {
  onGotoProfile = () => {
    this.props.navigation.navigate('Tasks');
  };

  

  render() {
    return (
      <View>
        <ImageBackground
          source={require('background.jpg')}
          style={{ width: '100%', height: '100%' }}>
          <View style={styles.container}>
            <Text style={styles.header}>Hello,</Text>
            <Text style={styles.text}>What's your focus today?</Text>
            <Button title="Tasks" onPress={this.onGotoProfile}/>
          </View>
        </ImageBackground>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: 'rgba(150,150,150,0.15)',
  },
  header: {
    fontFamily: 'Futura-MediumItalic',
    color: 'beige',
    fontWeight: 'bold',
    fontSize: 40,
    textAlign: 'center',
  },
  text: {
    fontFamily: 'Futura-MediumItalic',
    color: 'beige',
    fontSize: 25,
    textAlign: 'center',
  },
});

