import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { Constants } from 'expo';
import Timer from './Timer'
import { NavigationEvents} from 'react-navigation'

export default class Countdown extends React.Component {

  state = {
    message:''
  }

  render() {
    return (
      <View style={styles.container}>
         <NavigationEvents 
          onWillFocus ={ () => {
             const messageFromTheOtherSide = this.props.navigation.getParam('someMessage')
             this.setState({
               message: messageFromTheOtherSide
             })
          }}
        
        />
         <Text style = {{fontFamily: 'Futura-MediumItalic'}}>{this.state.message}</Text>
         <Timer/>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  }
});
